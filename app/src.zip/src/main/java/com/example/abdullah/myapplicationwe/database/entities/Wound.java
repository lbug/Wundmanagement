package com.example.abdullah.myapplicationwe.database.entities;

public class Wound {
    private long WoundID;
    private long timestamp;
    private String WoundImagePath;

    public Wound(long WoundID, long timestamp, String WoundImagePath) {
        this.WoundID = WoundID;
        this.timestamp = timestamp;
        this.WoundImagePath = WoundImagePath;
    }

    public long getWoundID() {
        return WoundID;
    }

    public void setWoundID(long woundID) {
        WoundID = woundID;
    }

    public long getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(long timestamp) {
        this.timestamp = timestamp;
    }

    public String getWoundImagePath() {
        return WoundImagePath;
    }

    public void setWoundImagePath(String woundImagePath) {
        WoundImagePath = woundImagePath;
    }

}
